# IBwallet

Este proyecto surge como proyecto final del curso en desarrollo web en la academia Coderhouse dictados por el docente Nicolas Seguro y la tutora Camila Muñoz Manríquez

<h1 align="center">Hi 👋, I'm Maximiliano Pisso</h1>
<h3 align="center">IT Talent Interbanker</h3>

<p align="left"> <img src="https://komarev.com/ghpvc/?username=maximilianopisso&label=Profile%20views&color=0e75b6&style=flat" alt="maximilianopisso" /> </p>

- 🌱 I’m currently learning **Curso de Desarrollo Web (HTML 5 y CSS) | JavaScript**

- 📫 How to reach me **maximiliano.pisso@gmail.com**

<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://linkedin.com/in/maximilianopisso" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="maximilianopisso" height="30" width="40" /></a>
</p>

<h3 align="left">Languages and Tools:</h3>
<p align="left"> <a href="https://www.w3schools.com/css/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/css3/css3-original-wordmark.svg" alt="css3" width="40" height="40"/> </a> <a href="https://www.w3.org/html/" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/html5/html5-original-wordmark.svg" alt="html5" width="40" height="40"/> </a> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> </p>
